import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    message.setBody('''
<?xml version="1.0" encoding="UTF-8"?>
<Products>
    <Product>
        <ID>1</ID>
        <Name>Apple</Name>
        <Description>Red Apple</Description>
        <Price>10.50</Price>
    </Product>
    <Product>
        <ID>2</ID>
        <Name>Banana</Name>
        <Description>Yellow Banana</Description>
        <Price>5.20</Price>
    </Product>
    <Product>
        <ID>3</ID>
        <Name>Orange</Name>
        <Description>Fresh Orange</Description>
        <Price>8.80</Price>
    </Product>
</Products>
'''.trim())

    return message
}